MediaInfo - http://MediaArea.net/MediaInfo
Copyright (c) MediaArea.net SARL, Info@MediaArea.net

License
-------
This program is freeware (BSD-style license).
See License.html for more information.


Compilation from source
-----------------------
* at the top of the archive, ./GUI_Compile.sh
or
* for each part of the project, cd Project/GNU/(project part name)/, ./configure, ./make

