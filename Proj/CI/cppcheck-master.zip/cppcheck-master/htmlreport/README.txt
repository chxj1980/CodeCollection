cppcheck-htmlreport

This is a little utility to generate a html report of a XML file produced by
cppcheck.

The utility is implemented in Python and require the pygments module to be
able to generate syntax highlighted source code.
If you are using a Debian based Linux system, the pygments package can be 
installed by following command:
$ sudo apt-get install python-pygments

For more information run './cppcheck-htmlreport --help'
