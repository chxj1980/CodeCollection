{
nodes: [
{host: 'localhost', port: 8125, adminport: 8126},
],
udp_version: 'udp4',
host:  '0.0.0.0',
port: 8127,
forkCount: 0,
checkInterval: 1000,
cacheSize: 10000
}
